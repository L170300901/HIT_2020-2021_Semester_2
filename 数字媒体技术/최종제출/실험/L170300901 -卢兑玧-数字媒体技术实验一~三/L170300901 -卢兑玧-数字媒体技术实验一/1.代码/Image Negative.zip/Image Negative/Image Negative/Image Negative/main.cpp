#include <stdio.h>
#include <windows.h>
#define WIDTHBYTES(bytes) (((bytes)+3)/4*4) 
int main(int argc, char *argv[])
{
	FILE *file;
	BITMAPFILEHEADER hf;
	BITMAPINFOHEADER hInfo;
	RGBQUAD rgb[256];
	int widthStep;
	BYTE *lpImg;
	BYTE *lpOutImg;
	int x, y;
	if (argc < 3) {
		printf("Insufficient Input Arguments \n");
		printf("  invertImage input_file ouput_file \n");
		return -1; 
	}
	file = fopen(argv[1], "rb"); 
	if (file == NULL) {
		printf("Unable to open image file \n"); 
		return -1;
	}
	fread(&hf, sizeof(BITMAPFILEHEADER), 1, file);
	if (hf.bfType != 0x4D42) {
		printf("Not a BMP file \n"); 
		return -1;
	}
	fread(&hInfo, sizeof(BITMAPINFOHEADER), 1, file);
	printf("Size: (%3dx%3d) \n", hInfo.biWidth, hInfo.biHeight);
	if ((hInfo.biBitCount != 8 || hInfo.biClrUsed != 0) && hInfo.biBitCount != 24) {
		printf("It's not an 8BIT GRAY-SCALE image \n"); 
		return -1;
	}
	if (hInfo.biBitCount == 8) {
		fread(rgb, sizeof(RGBQUAD), 256, file);
	}
	widthStep = WIDTHBYTES((hInfo.biBitCount / 8) * hInfo.biWidth);
	fseek(file, hf.bfOffBits, SEEK_SET);
	lpImg = (BYTE *)malloc(widthStep * hInfo.biHeight);
	fread(lpImg, sizeof(BYTE), widthStep*hInfo.biHeight, file); 
	fclose(file);
	lpOutImg = (BYTE *)malloc(widthStep * hInfo.biHeight);
	if (hInfo.biBitCount == 24) {
		for (y = 0; y < hInfo.biHeight; y++) {
			for (x = 0; x < hInfo.biWidth; x++) {
				lpOutImg[y*widthStep + 3 * x + 2] = 255 - lpImg[y*widthStep + 3 * x + 2];  /* R */
				lpOutImg[y*widthStep + 3 * x + 1] = 255 - lpImg[y*widthStep + 3 * x + 1];  /* G */
				lpOutImg[y*widthStep + 3 * x + 0] = 255 - lpImg[y*widthStep + 3 * x + 0];  /* B */
			}
		}
	}
	else if (hInfo.biBitCount == 8) {
		for (y = 0; y < hInfo.biHeight; y++) {
			for (x = 0; x < hInfo.biWidth; x++) {
				lpOutImg[y*widthStep + x] = 255 - lpImg[y*widthStep + x];
			}
		}
	}
	file = fopen(argv[2], "wb");

	fwrite(&hf, sizeof(char), sizeof(BITMAPFILEHEADER), file); 
	fwrite(&hInfo, sizeof(char), sizeof(BITMAPINFOHEADER), file); 
	if (hInfo.biBitCount == 8) { 
		fwrite(rgb, sizeof(RGBQUAD), 256, file);
	}
	fseek(file, hf.bfOffBits, SEEK_SET);
	fwrite(lpOutImg, sizeof(BYTE), widthStep*hInfo.biHeight, file);
	fclose(file);
	free(lpOutImg); 
	free(lpImg);
	return 0;

}